// Author: Mr. BR. Greaves
#include "NameConverter.h"
#include <vector>
#include <sstream>

using namespace std;

NameConverter::NameConverter()
{
    heroName = "";
    secretName = "";
}
string NameConverter::Scramble(string name){
    heroName = ToUpper(name); //Make the message upper case
    //Begin encoding message
    for(unsigned int i = 0; i < name.length(); i++){
        int index = -1; //Stores the index of the character in the text array to be correlated to the secret array
        char temp = heroName.at(i); //Get the character out of the string
        //Search the text array for the index of the character
        for(int j = 0; j < 37; j++){
            if(text[j].at(0) == temp){ //Compare every character in text to the temp character
                index = j;
            }
        }
        if(index != -1){ //Make sure we have a valid character
            secretName += scram[index]; //Convert the character to secret characters
        }
    }
    return secretName;
}
string NameConverter::Unscramble(string secret){
    secretName = ToUpper(secret); //Make the message upper case
    //Begin encoding message
    for(unsigned int i = 0; i < secret.length(); i++){
        int index = -1; //Stores the index of the character in the text array oto be correlated to the secret array
        char temp = secretName.at(i); //Get the character out of the string
        //Search the text array for the index of the character
        for(int j = 0; j < 37; j++){
            if(scram[j].at(0) == temp){ //Compare every character in text to the temp character
                index = j;
            }
        }
        if(index != -1){ //Make sure we have a valid character
            heroName += text[index]; //Convert the character to secret characters
        }
    }
    return heroName;
}

//Accessors and Mutators
string NameConverter::getHeroName(){
    return heroName;
}
string NameConverter::getSecretName(){
    return secretName;
}
void NameConverter::setHeroName(string msg){
    heroName = msg;
}
void NameConverter::setSecretName(string sec){
    secretName = sec;
}
string NameConverter::ToUpper(string msg){
    string temp = "";
    for(unsigned int i = 0; i < msg.length(); i++){
        temp += toupper(msg[i]); //Convert lower case characters to upper case
    }
    return temp;
}
