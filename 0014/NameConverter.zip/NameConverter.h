// Author: Mr. BR. Greaves
#ifndef NAMECONVERTER_H
#define NAMECONVERTER_H
#include <string>
#include <cstdlib>
#include <vector>

using namespace std;

class NameConverter
{
    public:
        //Constructor
        NameConverter();
        //Function to encode a message into morse code
        string Scramble(string name);
        //Function to decode morse code into a message
        string Unscramble(string secret);

        //Accessors and Mutators
        string getHeroName();
        string getSecretName();
        void setHeroName(string msg);
        void setSecretName(string sec);

    private:
        //Innter state for message
        string heroName;
        //Inner state for Secret name
        string secretName;
        //An array representing all of the alpha numeric characters that can be converted to Secret Characters
        string text[37] = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M",
                       "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
                       "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", " "};
        //Morse code corresponding to the letters in text
        string scram[37] = {"D", "U", "P", "1", "Q", "C", "I", "O", "5",
                        "7", "Z", "6", "V", "8", "W", "H", "T", "L",
                        "E", "0", "M", "J", "B", "4", "G", "9", "X",
                        "N", "3", " ", "2", "R", "Y", "K",
                        "S", "F", "A"};
        //Converts all characters to upper case
        string ToUpper(string msg);
};

#endif // MORSECODECONVERTER_H
