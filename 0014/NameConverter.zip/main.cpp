// Author: Mr. BR. Greaves
#include <iostream>
#include <string>
#include "NameConverter.h"

using namespace std;

int main()
{
    string name= ""; //Stores the hero name to be scrambled/unscrambled
    string result = "";  //Stores the result of scrambling/unscrambling
    string encode = "";  //Storees the options asked to the user
    NameConverter converter;

    cout << "Would you like to Scramble a hero name (Y) or Unscramble a hero name (N)?";
    cin >> encode;

    if(!encode.compare("Y")){
        //Scramble the inputted Hero name
        cout << "Please enter the Hero's name to scramble:";
        cin.ignore(); //Clears the new line character out of input buffer so we can enter a whole line
        getline(std::cin, name);
        //Scramble
        result = converter.Scramble(name); //Scramble the Name using the NameConverter
        cout << "Entered Hero Name: " << name << endl;
        cout << "Scrambled Hero Name:" << endl
        << "_________________________________" << endl
        << result << endl
        << "_________________________________";
    }
    else{
        //Unscramble Hero Name into Plain Text
        cout << "Please enter Secret Hero's name to unscramble:";
        cin.ignore(); //Clears the new line character out of input buffer so we can enter a whole line
        getline(std::cin, name);
        //Unscramble
        result = converter.Unscramble(name); //Unscramble the Name using NameComverter
        cout << "Entered Secret Name: " << name << endl;
        cout << "Unscrambled Hero Name:" << endl
        << "_________________________________" << endl
        << result << endl
        << "_________________________________";
    }
    return 0;
}
